# COSITMAZED

Tap-to-review pages for businesses using NFC cards. Every card points at a
COSITMAZED URL (`/review/your-slug`), which redirects the customer to that
business's Google review page. Because the destination lives in the
database instead of on the card, you can change where a card sends people
at any time — no re-encoding, no reprinting.

## How it works

```
NFC card  →  https://yourdomain.com/review/cafe-name  →  branded page  →  Google review link
```

- `/review/:slug` — the public, customer-facing page. Pure server-rendered
  HTML with the CSS inlined and no client-side JavaScript, so it loads
  instantly even on a shaky café Wi-Fi connection. The "Leave us a Google
  Review" button is a plain link straight to the business's Google review
  URL.
- `/admin` — a password-protected dashboard where you add businesses, edit
  their Google review link or logo, and copy the exact URL to encode onto
  an NFC card.
- Business data is stored in `data/businesses.json`. No external database
  needed to get started.

## Running it locally

Requires Node.js 18+.

```bash
npm install
npm start
```

Then visit:
- `http://localhost:3000/review/cafe-name` — the seeded example page
- `http://localhost:3000/admin` — the dashboard (default login below)

## Admin login

Set these environment variables before you deploy — the defaults are only
for local testing:

```bash
ADMIN_USER=youradminname
ADMIN_PASSWORD=a-strong-password
```

If unset, it falls back to `admin` / `changeme` and prints a warning on
startup. Don't ship that to production.

## Deploying

This is a plain Node/Express app, so it runs on any Node host. A few good
options:

- **Railway / Render** — connect the repo, set `ADMIN_USER` and
  `ADMIN_PASSWORD` in the environment settings, deploy. Both offer a
  persistent disk so `data/businesses.json` survives restarts and
  deploys — make sure the app's working directory is on that disk.
- **A basic VPS** — `npm install --production`, then run with `pm2` or a
  `systemd` service, behind Nginx/Caddy for HTTPS.
- **Vercel/Netlify serverless** — works, but their filesystems reset
  between deploys/invocations, so `data/businesses.json` won't persist
  writes. Swap `db.js` for a real database (Postgres, SQLite on a mounted
  volume, etc.) before using a serverless platform. The rest of the app
  (routes, templates, admin UI) doesn't need to change — only `db.js`'s
  four functions (`readAll`, `upsert`, `remove`, `findBySlug`) do.

Whichever host you pick, point your domain at it (e.g. `cositmazed.com`
or a subdomain) so your review links look like
`https://cositmazed.com/review/cafe-name`.

## Adding a business and setting up its NFC card

1. Go to `/admin` and click **Add business**.
2. Fill in the business name, a Google review link, and optionally a logo
   URL and tagline. The slug auto-fills from the name — this is what
   appears in the URL.
3. Save. The dashboard shows the full review URL for that business with a
   **Copy link** button.
4. Encode that exact URL onto the NFC card (any NFC-writing app — e.g. NFC
   Tools on Android/iOS — set the card's action to "Open URL" with this
   link).
5. Done. Tap the card, land on the branded page, tap the review button,
   land on Google.

## Changing where a card points, later

Open `/admin`, click **Edit** on the business, update the **Google review
link** field, save. The NFC card is untouched — it still points at
`/review/cafe-name`, which now serves the new destination.

## Project structure

```
cositmazed/
├── server.js              Express app and routes
├── db.js                  Reads/writes data/businesses.json
├── views.js                HTML templates (review page, 404, landing)
├── data/businesses.json    Business records (the "database")
├── public/
│   ├── css/admin.css
│   └── admin/
│       ├── index.html      Dashboard shell
│       └── app.js          Dashboard logic (list, add, edit, delete)
└── package.json
```

## Design

Deep ink (`#1B2430`) and porcelain (`#F7F5F1`) with a warm gold accent
(`#C9A15B`), a serif nameplate treatment for the business name, and a
single flat "plaque" surface rather than stacked cards — meant to feel
like a small physical token of thanks, not a generic landing page. No
web fonts are loaded on the public page, so the only network request
besides the page itself is the business's own logo image.
