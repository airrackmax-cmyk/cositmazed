const express = require('express');
const path = require('path');
const db = require('./db');
const { renderReviewPage, renderNotFound, renderLanding } = require('./views');

const app = express();
app.disable('x-powered-by');
app.use(express.json());

const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'changeme';

if (ADMIN_PASSWORD === 'changeme') {
  console.warn(
    '\n[COSITMAZED] WARNING: using the default admin password. Set ADMIN_USER and ADMIN_PASSWORD environment variables before deploying.\n'
  );
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, encoded] = header.split(' ');
  if (scheme === 'Basic' && encoded) {
    const [user, pass] = Buffer.from(encoded, 'base64').toString('utf8').split(':');
    if (user === ADMIN_USER && pass === ADMIN_PASSWORD) {
      return next();
    }
  }
  res.set('WWW-Authenticate', 'Basic realm="COSITMAZED Admin"');
  return res.status(401).send('Authentication required.');
}

function isValidSlug(slug) {
  return typeof slug === 'string' && /^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug);
}

function isValidUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch (err) {
    return false;
  }
}

// ---------- Public routes ----------

app.get('/', (req, res) => {
  res.send(renderLanding());
});

app.get('/review/:slug', (req, res) => {
  const business = db.findBySlug(req.params.slug);
  res.set('Cache-Control', 'public, max-age=60');
  if (!business) {
    return res.status(404).send(renderNotFound(req.params.slug));
  }
  res.send(renderReviewPage(business));
});

// ---------- Admin (protected) ----------

app.use('/admin', requireAuth, express.static(path.join(__dirname, 'public', 'admin')));

app.get('/api/businesses', requireAuth, (req, res) => {
  res.json(db.readAll());
});

app.post('/api/businesses', requireAuth, (req, res) => {
  const { slug, name, logoUrl, googleReviewUrl, tagline } = req.body || {};

  if (!isValidSlug(slug)) {
    return res.status(400).json({ error: 'Slug must be lowercase letters, numbers and hyphens only (e.g. "cafe-name").' });
  }
  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Business name is required.' });
  }
  if (!isValidUrl(googleReviewUrl)) {
    return res.status(400).json({ error: 'Google review link must be a valid URL.' });
  }
  if (logoUrl && !isValidUrl(logoUrl)) {
    return res.status(400).json({ error: 'Logo URL must be a valid URL.' });
  }
  if (db.findBySlug(slug)) {
    return res.status(409).json({ error: `A business with slug "${slug}" already exists.` });
  }

  const business = { slug, name: name.trim(), logoUrl: logoUrl || '', googleReviewUrl, tagline: tagline || '' };
  db.upsert(business);
  res.status(201).json(business);
});

app.put('/api/businesses/:slug', requireAuth, (req, res) => {
  const existing = db.findBySlug(req.params.slug);
  if (!existing) {
    return res.status(404).json({ error: 'Business not found.' });
  }

  const { name, logoUrl, googleReviewUrl, tagline } = req.body || {};

  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Business name is required.' });
  }
  if (!isValidUrl(googleReviewUrl)) {
    return res.status(400).json({ error: 'Google review link must be a valid URL.' });
  }
  if (logoUrl && !isValidUrl(logoUrl)) {
    return res.status(400).json({ error: 'Logo URL must be a valid URL.' });
  }

  const updated = { slug: existing.slug, name: name.trim(), logoUrl: logoUrl || '', googleReviewUrl, tagline: tagline || '' };
  db.upsert(updated);
  res.json(updated);
});

app.delete('/api/businesses/:slug', requireAuth, (req, res) => {
  if (!db.findBySlug(req.params.slug)) {
    return res.status(404).json({ error: 'Business not found.' });
  }
  db.remove(req.params.slug);
  res.status(204).end();
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`COSITMAZED running on http://localhost:${PORT}`);
  console.log(`Admin dashboard: http://localhost:${PORT}/admin (user: ${ADMIN_USER})`);
});
