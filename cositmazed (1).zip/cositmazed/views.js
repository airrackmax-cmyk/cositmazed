function escapeHtml(str = '') {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function originOf(url) {
  try {
    return new URL(url).origin;
  } catch (err) {
    return null;
  }
}

const BASE_STYLES = `
  :root {
    --ink: #1B2430;
    --ink-soft: #4B5563;
    --porcelain: #F7F5F1;
    --panel: #FFFFFF;
    --gold: #C9A15B;
    --gold-dark: #A9823F;
    --line: rgba(27, 36, 48, 0.12);
  }
  * { box-sizing: border-box; }
  html, body {
    margin: 0;
    padding: 0;
    background: var(--porcelain);
    color: var(--ink);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
    -webkit-text-size-adjust: 100%;
  }
  @media (prefers-reduced-motion: reduce) {
    * { animation-duration: 0.001ms !important; transition-duration: 0.001ms !important; }
  }
`;

function renderReviewPage(business) {
  const name = escapeHtml(business.name);
  const tagline = escapeHtml(business.tagline || 'Thanks for stopping by.');
  const logo = escapeHtml(business.logoUrl || '');
  const reviewUrl = escapeHtml(business.googleReviewUrl);
  const preconnect = originOf(business.googleReviewUrl);

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${name} — Leave a review</title>
<meta name="description" content="Leave ${name} a Google review in seconds.">
<meta name="theme-color" content="#1B2430">
${preconnect ? `<link rel="preconnect" href="${preconnect}"><link rel="dns-prefetch" href="${preconnect}">` : ''}
${logo ? `<link rel="apple-touch-icon" href="${logo}">` : ''}
<style>
${BASE_STYLES}
  .wrap {
    min-height: 100dvh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
  }
  .plaque {
    width: 100%;
    max-width: 400px;
    background: var(--panel);
    border: 1px solid var(--line);
    border-radius: 18px;
    padding: 40px 28px 32px;
    text-align: center;
    animation: rise 0.5s ease-out both;
  }
  @keyframes rise {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .logo-ring {
    width: 88px;
    height: 88px;
    margin: 0 auto 22px;
    border-radius: 50%;
    padding: 3px;
    background: linear-gradient(135deg, var(--gold), var(--gold-dark));
  }
  .logo-ring img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
    display: block;
    background: var(--panel);
    border: 3px solid var(--panel);
  }
  .name {
    font-family: ui-serif, "Iowan Old Style", "Palatino Linotype", Georgia, serif;
    font-size: 26px;
    line-height: 1.25;
    margin: 0 0 10px;
    letter-spacing: 0.01em;
  }
  .divider {
    width: 40px;
    height: 2px;
    background: var(--gold);
    margin: 0 auto 14px;
    border-radius: 2px;
  }
  .tagline {
    font-size: 15px;
    color: var(--ink-soft);
    margin: 0 0 28px;
    line-height: 1.5;
  }
  .cta {
    display: block;
    width: 100%;
    padding: 16px 20px;
    background: var(--ink);
    color: var(--porcelain);
    text-decoration: none;
    font-size: 16px;
    font-weight: 600;
    border-radius: 12px;
    transition: transform 0.15s ease, background 0.15s ease;
    border: none;
  }
  .cta:active {
    transform: scale(0.97);
    background: #0f151d;
  }
  .microcopy {
    font-size: 12.5px;
    color: var(--ink-soft);
    margin-top: 14px;
  }
  .footer {
    margin-top: 26px;
    font-size: 11px;
    color: #A1A8B3;
    letter-spacing: 0.02em;
  }
</style>
</head>
<body>
  <div class="wrap">
    <div class="plaque">
      ${logo ? `<div class="logo-ring"><img src="${logo}" alt="${name} logo" width="88" height="88" loading="eager"></div>` : ''}
      <h1 class="name">${name}</h1>
      <div class="divider"></div>
      <p class="tagline">${tagline}</p>
      <a class="cta" href="${reviewUrl}" rel="noopener">Leave us a Google Review ⭐</a>
      <p class="microcopy">Takes less than 30 seconds.</p>
      <p class="footer">Powered by COSITMAZED</p>
    </div>
  </div>
</body>
</html>`;
}

function renderNotFound(slug) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Page not found — COSITMAZED</title>
<meta name="theme-color" content="#1B2430">
<style>
${BASE_STYLES}
  .wrap { min-height: 100dvh; display: flex; align-items: center; justify-content: center; padding: 24px; }
  .plaque { width: 100%; max-width: 400px; text-align: center; border: 1px solid var(--line); border-radius: 18px; padding: 40px 28px; background: var(--panel); }
  h1 { font-family: ui-serif, "Iowan Old Style", "Palatino Linotype", Georgia, serif; font-size: 22px; margin: 0 0 10px; }
  p { color: var(--ink-soft); font-size: 14px; line-height: 1.6; margin: 0; }
  code { background: var(--porcelain); padding: 2px 6px; border-radius: 6px; font-size: 13px; }
</style>
</head>
<body>
  <div class="wrap">
    <div class="plaque">
      <h1>We can't find this page</h1>
      <p>There's no business set up at <code>/review/${escapeHtml(slug)}</code> yet. Check the link, or set it up from the admin dashboard.</p>
    </div>
  </div>
</body>
</html>`;
}

function renderLanding() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>COSITMAZED — NFC review pages for businesses</title>
<meta name="theme-color" content="#1B2430">
<style>
${BASE_STYLES}
  .wrap { min-height: 100dvh; display: flex; align-items: center; justify-content: center; padding: 24px; }
  .panel { max-width: 460px; text-align: center; }
  h1 { font-family: ui-serif, "Iowan Old Style", "Palatino Linotype", Georgia, serif; font-size: 30px; margin: 0 0 12px; }
  p { color: var(--ink-soft); font-size: 15px; line-height: 1.6; margin: 0 0 26px; }
  a.button { display: inline-block; padding: 14px 26px; background: var(--ink); color: var(--porcelain); text-decoration: none; border-radius: 12px; font-weight: 600; font-size: 15px; }
</style>
</head>
<body>
  <div class="wrap">
    <div class="panel">
      <h1>COSITMAZED</h1>
      <p>Tap-to-review pages for businesses using NFC cards. Point every card at a COSITMAZED link, and change where it sends customers any time — no new cards needed.</p>
      <a class="button" href="/admin">Go to dashboard</a>
    </div>
  </div>
</body>
</html>`;
}

module.exports = { renderReviewPage, renderNotFound, renderLanding, escapeHtml };
