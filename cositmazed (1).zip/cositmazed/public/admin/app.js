const listEl = document.getElementById('list');
const modalRoot = document.getElementById('modal-root');
const toastEl = document.getElementById('toast');
const addBtn = document.getElementById('add-btn');

function showToast(message) {
  toastEl.textContent = message;
  toastEl.classList.add('show');
  setTimeout(() => toastEl.classList.remove('show'), 2200);
}

function slugify(text) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

async function fetchBusinesses() {
  const res = await fetch('/api/businesses');
  if (!res.ok) throw new Error('Could not load businesses.');
  return res.json();
}

function reviewUrlFor(slug) {
  return `${window.location.origin}/review/${slug}`;
}

function renderList(businesses) {
  if (!businesses.length) {
    listEl.innerHTML = `<div class="empty">No businesses yet. Add one to get its review link and point an NFC card at it.</div>`;
    return;
  }

  listEl.innerHTML = businesses
    .map((b) => {
      const url = reviewUrlFor(b.slug);
      const thumb = b.logoUrl
        ? `<img class="thumb" src="${b.logoUrl}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'thumb-fallback',textContent:'${(b.name[0] || '?').toUpperCase()}'}))">`
        : `<div class="thumb-fallback">${(b.name[0] || '?').toUpperCase()}</div>`;

      return `
        <div class="row" data-slug="${b.slug}">
          ${thumb}
          <div class="info">
            <div class="name">${b.name}</div>
            <div class="link">
              <code>${url}</code>
              <a class="preview-link" href="${url}" target="_blank" rel="noopener">Preview →</a>
            </div>
          </div>
          <div class="actions">
            <button class="btn btn-ghost btn-sm" data-action="copy" data-url="${url}">Copy link</button>
            <button class="btn btn-ghost btn-sm" data-action="edit">Edit</button>
            <button class="btn btn-danger btn-sm" data-action="delete">Delete</button>
          </div>
        </div>`;
    })
    .join('');
}

let cache = [];

async function refresh() {
  cache = await fetchBusinesses();
  renderList(cache);
}

function closeModal() {
  modalRoot.innerHTML = '';
}

function openForm(existing) {
  const isEdit = !!existing;
  modalRoot.innerHTML = `
    <div class="overlay" id="overlay">
      <div class="modal">
        <h2>${isEdit ? 'Edit business' : 'Add business'}</h2>
        <div id="form-error"></div>
        <form id="biz-form">
          <div class="field">
            <label for="f-name">Business name</label>
            <input id="f-name" required value="${existing ? existing.name : ''}">
          </div>
          <div class="field">
            <label for="f-slug">Slug (used in the URL)</label>
            <input id="f-slug" required ${isEdit ? 'disabled' : ''} value="${existing ? existing.slug : ''}">
            <div class="hint">${isEdit ? existing.slug : 'Auto-fills from the name — lowercase letters, numbers, hyphens.'}</div>
          </div>
          <div class="field">
            <label for="f-google">Google review link</label>
            <input id="f-google" required placeholder="https://g.page/r/…/review" value="${existing ? existing.googleReviewUrl : ''}">
            <div class="hint">This is the only field you'll need to change later — the NFC card never has to move.</div>
          </div>
          <div class="field">
            <label for="f-logo">Logo URL (optional)</label>
            <input id="f-logo" placeholder="https://…/logo.png" value="${existing ? existing.logoUrl || '' : ''}">
          </div>
          <div class="field">
            <label for="f-tagline">Tagline (optional)</label>
            <input id="f-tagline" placeholder="Thanks for stopping by." value="${existing ? existing.tagline || '' : ''}">
          </div>
          <div class="modal-actions">
            <button type="button" class="btn btn-ghost" id="cancel-btn">Cancel</button>
            <button type="submit" class="btn btn-primary">${isEdit ? 'Save changes' : 'Add business'}</button>
          </div>
        </form>
      </div>
    </div>
  `;

  const nameInput = document.getElementById('f-name');
  const slugInput = document.getElementById('f-slug');
  if (!isEdit) {
    nameInput.addEventListener('input', () => {
      slugInput.value = slugify(nameInput.value);
    });
  }

  document.getElementById('cancel-btn').addEventListener('click', closeModal);
  document.getElementById('overlay').addEventListener('click', (e) => {
    if (e.target.id === 'overlay') closeModal();
  });

  document.getElementById('biz-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      name: nameInput.value.trim(),
      slug: slugify(slugInput.value),
      googleReviewUrl: document.getElementById('f-google').value.trim(),
      logoUrl: document.getElementById('f-logo').value.trim(),
      tagline: document.getElementById('f-tagline').value.trim(),
    };

    const url = isEdit ? `/api/businesses/${existing.slug}` : '/api/businesses';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        document.getElementById('form-error').innerHTML = `<div class="error-banner">${data.error || 'Something went wrong.'}</div>`;
        return;
      }
      closeModal();
      showToast(isEdit ? 'Changes saved.' : 'Business added.');
      refresh();
    } catch (err) {
      document.getElementById('form-error').innerHTML = `<div class="error-banner">Network error — please try again.</div>`;
    }
  });
}

function confirmDelete(business) {
  modalRoot.innerHTML = `
    <div class="overlay" id="overlay">
      <div class="modal">
        <h2>Delete ${business.name}?</h2>
        <p style="color:var(--ink-soft); font-size:14px; margin-top:-8px;">
          Its review link will stop working immediately. This can't be undone.
        </p>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" id="cancel-btn">Cancel</button>
          <button type="button" class="btn btn-danger" id="confirm-btn">Delete</button>
        </div>
      </div>
    </div>
  `;
  document.getElementById('cancel-btn').addEventListener('click', closeModal);
  document.getElementById('overlay').addEventListener('click', (e) => {
    if (e.target.id === 'overlay') closeModal();
  });
  document.getElementById('confirm-btn').addEventListener('click', async () => {
    await fetch(`/api/businesses/${business.slug}`, { method: 'DELETE' });
    closeModal();
    showToast('Business deleted.');
    refresh();
  });
}

addBtn.addEventListener('click', () => openForm(null));

listEl.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-action]');
  if (!btn) return;
  const row = btn.closest('.row');
  const slug = row.dataset.slug;
  const business = cache.find((b) => b.slug === slug);

  if (btn.dataset.action === 'copy') {
    navigator.clipboard.writeText(btn.dataset.url).then(() => showToast('Link copied.'));
  } else if (btn.dataset.action === 'edit') {
    openForm(business);
  } else if (btn.dataset.action === 'delete') {
    confirmDelete(business);
  }
});

refresh().catch(() => {
  listEl.innerHTML = `<div class="empty">Could not load businesses. Refresh the page.</div>`;
});
