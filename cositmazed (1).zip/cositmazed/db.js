const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data', 'businesses.json');

function readAll() {
  try {
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    return [];
  }
}

function writeAll(businesses) {
  fs.writeFileSync(DB_PATH, JSON.stringify(businesses, null, 2), 'utf8');
}

function findBySlug(slug) {
  return readAll().find((b) => b.slug === slug);
}

function upsert(business) {
  const businesses = readAll();
  const i = businesses.findIndex((b) => b.slug === business.slug);
  if (i === -1) {
    businesses.push(business);
  } else {
    businesses[i] = business;
  }
  writeAll(businesses);
  return business;
}

function remove(slug) {
  const businesses = readAll().filter((b) => b.slug !== slug);
  writeAll(businesses);
}

module.exports = { readAll, writeAll, findBySlug, upsert, remove };
